use strict;
use warnings;
my $str = 'Gavs Tech'; 
my @arr = split //, $str; 
my $len = @arr; 
my $rev = ''; 
while ($len>=0) 
{ 
        $rev.=$arr[$len]; 
        $len--; 
} 
print "\n$rev\n";
