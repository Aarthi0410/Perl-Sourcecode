use strict;
no warnings;
my %numbers = (
    1 => 100,
    2 => 200,
    3 => 300,
    4 => 400,
    5 => 500
);
my $a=0;
my @k = keys %numbers;
my @v = values %numbers;
for(my $i=0;$i<=scalar(%numbers);$i++){
     $a+=@k[$i]*@v[$i]; 
}
print "$a"."\n";