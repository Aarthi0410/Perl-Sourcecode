use warnings;

#From 1 o 100, print the numbers mutiple with 2, 3 and 5.
#Eg:
#Input => 1, 2, 3, .. 100

for(my $num=1;$num<=100;$num++)
{
        if(
        (
            ($num%2==0)&&
            ($num%3==0)&&
            ($num%5==0)
        )
    ){
    print "$num is divisible by 2, 3 and 5"."\n";
    }
     
}
# 60 is divisible by 2, 3 and 5
# 90 is divisible by 2, 3 and 5
