use strict;
no warnings;
my $count=0;
my $str = "apple is a fruit"; 
my @arr = split //, $str; 
my $len = @arr; 
my $rev = ''; 

while ($len>=0) 
{ 
        if (
            ($arr[$len] eq "a")||
            ($arr[$len] eq "e")||
            ($arr[$len] eq "i")|| 
            ($arr[$len] eq "o")||
            ($arr[$len] eq "u") 
        ){
           $count=$count+1;
        }
        $len--; 
} 

print "There are ".$count." vowels in the string\n";
