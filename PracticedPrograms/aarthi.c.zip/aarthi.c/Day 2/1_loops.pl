use strict;
use warnings;
 

#Looping

#for loop
for (my $i = 1 ; $i <= 5 ; $i++)
{
    print "hello \n"
}

my @arr = ( 'hi', 'hello');
 
# foreach loop
my $arr1;

foreach $arr1 (@arr)
{
    print "$arr1\n";
}

#while loop

my $k = 3;
while ($k >= 0)
{
    $k = $k - 1;
    print "welcome\n";
}

# do..While loop

 my $a = 5;

do {
    print "$a ";
    $a = $a - 1;
} while ($a > 0);

#loop Control Statement

# until loop
$a=10;
print "\n";
until ($a < 1)
{
    print "$a ";
    $a = $a - 1;
}