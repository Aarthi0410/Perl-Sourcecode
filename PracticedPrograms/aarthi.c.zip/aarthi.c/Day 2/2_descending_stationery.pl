use strict;
 no warnings;

my @stationeryitems = ();
print "Enter the  no.of Stationery Items::";
my $items =<STDIN>;
for(my $i=1; $i<=scalar($items); $i++)
{
    print "enter the $i items::";
    $stationeryitems[$i]= <STDIN>;
}
my @order=sort {$b cmp $a} @stationeryitems;
print "Array in descending order:: \n @order";
