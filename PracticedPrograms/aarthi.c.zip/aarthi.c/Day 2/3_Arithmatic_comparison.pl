use strict;
no warnings;

my $Num1 = <STDIN>;
my $Num2 = <STDIN>;

my $Addition=$Num1+$Num2;
my $Subtraction=$Num1-$Num2;
my $Division=$Num1/$Num2;
my $Multiplication=$Num1*$Num2;
my $Difference=$Num1 % $Num2;

print "Addition is $Addition \n" ;
print  "Subtraction is $Subtraction \n" ;
print  "Division is $Division \n" ;
print  "AMultiplication is $Multiplication \n" ;
print  "Remainder is $Difference \n" ;

if($Num1 == $Num2)
{
    print "Num1 == Num2 is true \n";
}
else{
    print "Num1 == Num2 is false \n";
}

# my $Lesserthan =$Num1 < $Num2;
if($Num1 < $Num2)
{
    print "Num1 < Num2 is true \n";
}
else{
    print "Num1 < Num2 is false \n";
}
# my $Greaterthan =$Num1 > $Num2;
if($Num1 > $Num2)
{
    print "Num1 > Num2 is true \n";
}
else{
    print "Num1 > Num2 is false \n";
}
# my $NE =$Num1 != $Num2;
if($Num1 != $Num2)
{
    print "Num1 != Num2 is true \n";
}
else{
    print "Num1 != Num2 is false  \n";
}
# my $LOE =$Num1 <= $Num2;
if($Num1 <= $Num2)
{
    print "Num1 <= Num2 is true \n";
}
else{
    print "Num1 <= Num2 is false \n";
}
# my $GOE =$Num1 >= $Num2;
if($Num1 >= $Num2)
{
    print "Num1 >= Num2 is true \n";
}
else{
    print "Num1 >= Num2 is false \n";
}
# my $CMP =$Num1 <=> $Num2;
if($Num1 <=> $Num2)
{
    print "Num1 <=> Num2 is true \n";
}
else{
    print "Num1 <=> Num2 is false \n";
}

