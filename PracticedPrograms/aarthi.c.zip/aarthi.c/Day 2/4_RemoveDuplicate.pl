use strict;
no warnings;
use Data::Dumper;

my @input = ( 3, 1, 2, 'gavs', 1, '1', 'def', 'gavs', 'abc');
my %arr;

foreach my $i (@input)
{
    $arr{$i}=1;
}
@input=keys %arr;
my @sorted = sort { $a cmp $b||$a <=> $b }@input;
print Dumper "\ @sorted";
