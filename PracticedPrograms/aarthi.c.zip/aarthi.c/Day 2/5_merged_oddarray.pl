use strict;
 no warnings;

my @numbers1 = ( 1, 2, 3, 4, 5);
my @numbers2 = ( 6, 7, 8, 9, 10, 11);
my @array1=();
my @array2=();
my $j=0;
my $k=0;
for(my $i=0;$i<scalar(@numbers1);$i++){
    if(($i%2)!=0){
        @array1[$j]=@numbers1[$i];
        $j++;
    }
}
for(my $i=0;$i<scalar(@numbers2);$i++){
    if(($i%2)!=0){
        @array2[$k]=@numbers2[$i];
        $k++;
    }
}
my @mergedArray=(@array1,@array2);
my $arr=join(",",@mergedArray);
# my $splitArray=split(",",@mergedArray);
# print $splitArray;
print $arr;