use strict;
use warnings;
use Data::Dumper;
my $i=10;
my %fruits = ();
while($i!=0) {
    print "Enter a fruit name :: ";
    my $key = <STDIN>;
    chomp $key;

    print "Enter a fruit count :: ";
    my $value = <STDIN>;
    chomp $value;

    $fruits{$key} = $value;
    $i--;  

}
for my $order (reverse sort keys %fruits) {
     printf "\t% -20s%5d\n", $order, $fruits{$order};
   }
