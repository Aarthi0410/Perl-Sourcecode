open (WRITE, ">file1.txt");
my @array=('a'..'z');
for($i=0;$i<@array;$i++){
    my $j=@array[$i];
   print WRITE "$j \n";
}

# foreach my $j('a'..'z'){
#  print WRITE "@array\n";
# }
close (WRITE);