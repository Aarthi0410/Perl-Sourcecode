open (READ, "<file1.txt");
my @lines = <READ>;
close (READ);
print reverse(@lines)."\n";
