use strict;
use warnings;

open (READ,"<myfile.txt");
my @lines=<READ>;
close(READ);
open(WRITE,">myfile2.txt");

for my $arr(@lines){
    if($arr=~m/(\w+)melon|(\s)melon/ig){   
        print WRITE $arr;
    }
}
close(WRITE);
