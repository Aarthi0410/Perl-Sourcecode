
use strict;
use warnings;
use feature qw /say/;

my @nums = @ARGV > 1 ? @ARGV : (-1, 1, 2, 3, 0, -2, 7, 8);
my @sorted = sort { $a <=> $b } grep $_ >= 0, @nums;
die "No solution !" if @sorted < 1;
my $result;
for my $i (0..scalar @nums - 1) {
    $result = ($sorted[$i] + 1) and last 
        if $sorted[$i] + 1 < $sorted[$i+1];
}
say $sorted[-1] + 1 and exit unless defined $result;
print  $result ;





# Our program receives the list of numbers as a parameter
#  (or takes a default list of integers if none is provided).
#   It removes any negative values, sorts the remaining integers,
#    and remove any duplicate (although removing duplicates is not strictly necessary). 
#    It then loops through the sorted array,
#     picks the first gap (missing value) into the $result variable and exits the loop. 
#     Then it prints the value of result if it is defined, or the last value of the sorted array + 1 
#     if $result is not defined (i.e. if no gap was found).