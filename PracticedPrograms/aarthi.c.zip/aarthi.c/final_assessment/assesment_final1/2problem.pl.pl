use strict;

 my @array=(4,4,5,3);
my $sum=8;
my $count=0;
print "The combinations are\n";
for(my $i=0;$i<scalar(@array);$i++){
    for(my $j=$i+1;$j<scalar(@array);$j++){
         
         print @array[$i].','.@array[$j];
         print "\n";
         my $sum2=@array[$i]+@array[$j];
         if($sum2==$sum){
             $count++;
         }
         
    }
}
print "count is ".$count;