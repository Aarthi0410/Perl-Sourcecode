use strict;
my @arr1 = (10,20,30,40,60);
my @arr2 = (70,80,90,100,200);
my $sum=0;


for(my $index1=0; $index1<scalar(@arr1); $index1++) {
    if($index1 % 2==0){
           $sum+=@arr1[$index1];
    }
    else{
        $sum+=@arr2[$index1];
    }

}
print $sum;
    # for(my $index2=0; $index2<scalar(@arr2); $index2++) {
    #    if($index1 % 2!=0){
    #        $sum+=@arr2[$index2];
    # }
    # }

