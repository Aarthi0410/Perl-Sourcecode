use strict;
use warnings;

my $full_name = 'Hello Gary Williams';
my ($middle, $first, $last) = $full_name =~ /([\w'-]+)/g;

print "First Name: $first\nLast Name: $last";