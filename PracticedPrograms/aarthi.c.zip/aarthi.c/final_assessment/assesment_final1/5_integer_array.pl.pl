use strict;
use warnings;

my @array=(1, 2, 'a', 'b', '3', 'c', '4', 'd', 5);

my @a= grep/\d/,@array;
print join(",",@a);
