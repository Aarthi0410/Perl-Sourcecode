# 6. Sum the diagonal elements(1+6+3+8) in a given multi-dimensional array.
# $arr = [[1,2,3,4],
# [5,6,7,8],
# [1,2,3,4],
# [5,6,7,8]]
# Output:18

use strict;
use Data::Dumper;

# Arrays of Arrays
my @arrayofarray = (
 [1,2,3,4],
 [5,6,7,8],
 [1,2,3,4],
 [5,6,7,8]
);
my $sum=0;


for(my $index1=0; $index1<scalar(@arrayofarray); $index1++) {
    my @array2 = @{$arrayofarray[$index1]};
    for(my $index2=0; $index2<=$#array2; $index2++) {
       if($index1==$index2){
        $sum+=$arrayofarray[$index1][$index2];
      }
    }
}
print $sum;