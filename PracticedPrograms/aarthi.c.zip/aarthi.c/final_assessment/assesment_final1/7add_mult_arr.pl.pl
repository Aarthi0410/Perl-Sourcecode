use strict;
# Perform sum for 1st & 3rd column and multiplication
#  for 2nd & 4th column in a given multidimentional array.
# $arr = [[1,2,3,4],[5,6,7,8],[1,2,3,4],[5,6,7,8]]
my @arrayofarray = (
    [1,2,3,4],
[5,6,7,8],
[1,2,3,4],
[5,6,7,8]
);
 my $sum=0;
  my $mult=1;
for(my $index1=0; $index1<scalar(@arrayofarray); $index1++) {
      $sum=0;
      $mult=1;
      my @array2 = @{$arrayofarray[$index1]};
     if($index1 % 2==0){
        for(my $index2=0; $index2<=$#array2; $index2++) {
            $sum+=$arrayofarray[$index2][$index1];
          }
           print "sum of $index1\'th column =$sum"."\n";
      }
      
     else{
        for(my $index2=0; $index2<=$#array2; $index2++) {
           $mult*=$arrayofarray[$index2][$index1];
          }
           print "multiplication of $index1\'th column =$mult"."\n";
      }
    
   
}