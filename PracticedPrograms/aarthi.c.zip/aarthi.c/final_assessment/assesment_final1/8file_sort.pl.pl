use strict;
use warnings;

open (READ, "<sampleFile.txt");
my @lines = <READ>;
close (READ);
my @line = sort (@lines);
open (WRITE, ">sample1.txt");
print WRITE @line;
close (WRITE);

