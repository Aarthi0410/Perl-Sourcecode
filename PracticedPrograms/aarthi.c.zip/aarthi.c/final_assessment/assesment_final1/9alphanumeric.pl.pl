
use strict;
use warnings;
my $str="abc123def";
$str=~s/\d//;
my $str1=reverse($str);
print $str1;