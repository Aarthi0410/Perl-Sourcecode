use strict;

my $input = 12345;
my $add1 = 0;
my $add2 = 0;
foreach (my $i = 0; $i < length($input); $i++) {
    my $result = $input % 10;
    if ($i % 2 == 0) {
        $add1 += $result;
    }
    else {
        $add2 += $result;
    }
    $input /= 10;
}
if ($add1 - $add2 == 0) {
    print " yes";
}
else {
    print " No";
}