use strict;
use POSIX qw/floor/;
my @arr = (16, 6, 8, 4, 144);
for(my $i=0;$i<scalar(@arr);$i++){
    my $square_root = sqrt($arr[$i]);#//finding square_root
    my $ceil = floor($square_root);#//getting whole number for checking whether it is perfect square or not.
    my $sum=$square_root*$square_root;#//squaring the whole number for getting same value..if the number is same ,then its a perfect square..
    if($sum==@arr[$i]){
        print @arr[$i]." ";
    }
}

