use strict;

my %names = (
    3 => 'Apple',
    5 => 'Water Melon',
    10 => 'Orange',
    2 => 'Fig'
);
my @output=();

while ( (my $key, my $value) = each(%names))
 {
    my $val = "";

    for (my $i= 0; $i<= length($value); $i++)
     {
        next if ($i== $key);
        $val = $val.substr($value, $i, 1);
    }
    push @output, $val;
}
print join (', ', @output);