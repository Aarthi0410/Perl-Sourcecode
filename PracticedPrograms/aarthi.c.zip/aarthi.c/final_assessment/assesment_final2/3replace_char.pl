use strict;
use warnings;
my $text = 'Gavs Technologies';

print "Enter the character: \n";
my $char = <STDIN>;
chomp $char;

print "Enter the index: \n";
my $index = <STDIN>;

substr($text,$index,1)=$char;
print $text;