use 5.010;
use strict;
use warnings;
use Data::Dump qw(dump);
 
my @matrix = (
    [1,2,3,4],
    [5,6,7,8],
    [1,2,3,4],
    [5,6,7,8]
);
 
say dump \@matrix;
my @tr;
for my $row (0..@matrix-1) {
    for my $col (0..@{$matrix[$row]}-1) {
        $tr[$col][$row] = $matrix[$row][$col];
    }
}
say dump \@tr;

#for(my $i=0;$i<calar(@matrix);$i++){
    #for(my $j=0;$j<@{$matrix[$row]};$j++){
        #$tr[$col][$row]=$matrix[$row][$col];
    #}
#}