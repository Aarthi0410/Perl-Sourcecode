#Compound Interest = P(1 + R/100)^T
use strict;
use POSIX qw/floor/;
my $p=1200;
my $rate=2;
my $t=5.4;
my $Compound_int=$p*(1+$rate/100)**$t;
print floor($Compound_int);

