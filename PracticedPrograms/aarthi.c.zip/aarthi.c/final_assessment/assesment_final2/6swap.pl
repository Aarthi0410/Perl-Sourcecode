use strict;
use Data::Dumper;
my @array=(12, 35, 9, 56, 24);
my $temp=0;
my $size_of_array = @array;
$temp=@array[0];
@array[0]=@array[$size_of_array-1];
@array[$size_of_array-1]=$temp;

print Dumper \@array;
