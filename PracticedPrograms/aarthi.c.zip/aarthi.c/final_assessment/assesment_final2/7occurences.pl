use strict;
use warnings;
use Data::Dumper;

my @arr = ('sun', 'mon', 'tue', 'sun', 'mon', 'tue', 'mon', 'tue', 'thu');
my %count=();
foreach my $word(@arr) 
{
    $count{$word}++;
}
  print Dumper \%count;


