use strict;
use warnings;
use 5.010;

my @keys = ("a", "b", "c", "d", "e", "f", "g", "h", "i");
my @values = ( 0, 1, 1, 0, 1, 2, 2, 0, 1);
my %hash;
@hash{@keys} = @values;
foreach my $name (sort {$hash{$a} <=> 
       $hash{$b}} keys %hash) 
{
    printf "%-8s %s\n", $name, $hash{$name};
}

