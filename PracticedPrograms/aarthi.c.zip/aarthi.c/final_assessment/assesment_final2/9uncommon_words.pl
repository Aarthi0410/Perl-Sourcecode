use strict;
use Data::Dumper;
use warnings;

my $A = "Internet";
my $B = "Learning from Internet";
my @out1 = split (' ', $A);
my @out2 = split (' ', $B);
my @out3 = (@out1, @out2); 
my @result=();

for (my $index1 = 0; $index1 < scalar(@out3); $index1++) {
    my $count = 0;
    for (my $index2 = 0; $index2 < scalar(@out3); $index2++) {
        if ($out3[$index1] eq $out3[$index2]) {
            $count++;
        }
    }
    if ($count == 1) {
        push @result, $out3[$index1];
    }
}
print Dumper \@result;