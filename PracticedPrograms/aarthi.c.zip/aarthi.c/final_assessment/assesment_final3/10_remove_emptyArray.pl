use strict;
no warnings;
use Data::Dumper;

my @x=([], [], ['',], ['a', 'b'], ['a', 'b', 'c'], ['d']);
my @y=();

for (my $i=0; $i<scalar(@x);$i++)
{
    if( $x[$i][0] ne undef)
    {
        push @y, $x[$i];
    }
}
print Dumper \@y;