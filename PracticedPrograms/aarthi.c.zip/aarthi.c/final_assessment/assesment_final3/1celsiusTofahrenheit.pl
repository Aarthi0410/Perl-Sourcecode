use strict;

print "Enter the celsius:: \n";
my $celsius = <STDIN>;
chomp $celsius;

print "Enter the fahrenheit:: \n";
my $fahrenheit = <STDIN>;
chomp $fahrenheit;

my $Celsius;
my $Fahrenheit;

$Fahrenheit=(9*$celsius/5)+32;
print"$celsius °C is $Fahrenheit in Fahrenheit\n"; 

$Celsius= 5/9*($fahrenheit-32);
print "$fahrenheit °f is $Celsius in Celsius \n";

