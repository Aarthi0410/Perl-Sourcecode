use strict;
use warnings;

my $num1=5;
my $num2=4;

for (my $i = 0; $i <$num1; $i++){
    for (my $j = 0; $j < $i + 1; $j++){
        print("*");
    }
    print("\n");
}
for (my $i = 1; $i <= $num2; $i++) {
    for (my $j = $i; $j <= $num2; $j++){
        print("*");
    }
    print("\n");
}