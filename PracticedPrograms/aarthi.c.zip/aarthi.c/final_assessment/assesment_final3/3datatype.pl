use strict;
use Scalar::Util qw(reftype);

my @array = (
    1452,
    11.23,
    undef,
    'True',
    'w3resource',
    [0, -1],
    {class => 'V', section => 'A'}
);
foreach (@array) {
    if ($_ eq undef) {
        print "UNDEF\n";
    }
    elsif ((reftype($_) eq "ARRAY") or (reftype($_) eq "HASH")) {
        print reftype($_)."\n";
    }
    else {
        print "SCALAR\n";
    }
}