use strict;
use warnings;
for my $n (1..50) {
    if($n % 3==0 && $n % 5==0){
        print("ABCXYZ\n");
    }
    elsif($n % 5==0){
        print("XYZ\n");
    }
    elsif($n % 3==0){
        print("ABC\n");
    }
    else{
        print "$n\n";
    }
    
}