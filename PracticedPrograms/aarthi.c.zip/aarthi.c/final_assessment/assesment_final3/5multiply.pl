
use strict;
use warnings;
use Data::Dumper;
my $a=3;
my $b=4;
my @matrix=();
for (my $i=0; $i<$a; $i++) {
    for (my $j=0; $j<$b; $j++) {
        $matrix[$i][$j] = $i*$j;
    }
}

print Dumper \@matrix;