use strict;

print "Enter the password :: ";
my $password = <STDIN>;
chomp $password;

my $word = 0;
$word++ if ($password =~ /[A-Z]/);
$word++ if ($password =~ /[a-z]/);

$word++ if ($password =~ /[0-9]/);
$word++ if ($password =~ /[\$\#@]/);
$word++ if ($password =~ /.{6,16}/);
if ($word > 4) {
    print "Correct  Password.";
}
else {
    print "Incorrect Password";
}