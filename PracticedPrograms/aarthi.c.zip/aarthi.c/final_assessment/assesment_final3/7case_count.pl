use strict;

print "Enter a word :: \n";
my $a= <STDIN>;
chomp $a;
my $uc = 0;
my $lc = 0;
while ($a=~ /[A-Z]/g) {
    $uc++;
}
while ($a =~ /[a-z]/g) {
    $lc++;
}
print "Number of upper characters : $uc\n";
print "Number of lower characters : $lc\n";