use strict;
use warnings;
use 5.010;
 
use List::MoreUtils qw(uniq);
use Data::Dumper ;
 
my @num = qw(1 2 3 3 3 3 4 5);
my @unique_num = uniq @num;
 
print Dumper \@unique_num;