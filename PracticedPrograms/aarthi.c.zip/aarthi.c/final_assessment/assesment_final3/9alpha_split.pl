use warnings;
use strict;

my $string = 'green-red-yellow-black-white';
my @split= split ('-', $string);
my @sorting = sort @split;
print join ('-', @sorting);